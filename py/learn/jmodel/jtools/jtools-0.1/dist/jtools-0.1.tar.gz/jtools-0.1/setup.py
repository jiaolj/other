"""
from distutils.core import setup
setup(name='jtools',
      version='0.1',
      description="841232468@qq.com 2015-05-13",
      author="Jiao Luo Jun",
      license="LGPL",
      py_modules=['jtools'],
      )
"""
from setuptools import setup, find_packages

setup(
    name = 'jtools',
    version = 0.1,
    packages = find_packages(),
    author = 'Jiao Luo Jun',
    author_email = '841232468@qq.com',
    url = '',
    license = '',
    description = '2015-05-13'
    ) 