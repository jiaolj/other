from distutils.core import setup
setup(name='jmysql',
      version='0.1',
      description="841232468@qq.com 2015-05-12",
      author="Jiao Luo Jun",
      license="LGPL",
      py_modules=['JMysql'],
      )